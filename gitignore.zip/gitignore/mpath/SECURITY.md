# Reporting a Vulnerability

Please report suspected security vulnerabilities to val [at] karpov [dot] io.
You will receive a response from us within 72 hours.
If the issue is confirmed, we will release a patch as soon as possible depending on complexity.
