/**
 * Export lib/mongoose
 *
 */

'use strict';

module.exports = require('./lib/browser');
