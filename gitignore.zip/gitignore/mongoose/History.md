This file has been renamed [CHANGELOG.md](./CHANGELOG.md)
